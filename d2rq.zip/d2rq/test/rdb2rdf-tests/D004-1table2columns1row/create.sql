CREATE TABLE "Student_Sport"(
      "Student" varchar(50),
      "Sport" varchar(50)
);
INSERT INTO "Student_Sport" ("Student","Sport") VALUES ('Venus', 'Tennis');
