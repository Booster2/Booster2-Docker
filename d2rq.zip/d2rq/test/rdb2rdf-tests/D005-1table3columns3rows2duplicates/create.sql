CREATE TABLE "IOUs" (
      "fname" VARCHAR(20),
      "lname"  VARCHAR(20),
      "amount" FLOAT);
INSERT INTO "IOUs" ("fname", "lname", "amount") VALUES ('Bob', 'Smith', 30);
INSERT INTO "IOUs" ("fname", "lname", "amount") VALUES ('Sue', 'Jones', 20);
INSERT INTO "IOUs" ("fname", "lname", "amount") VALUES ('Bob', 'Smith', 30);
