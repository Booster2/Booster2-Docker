package org.d2rq.db.renamer;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	ColumnRenamerTest.class,
	TableRenamerTest.class
})

public class AllTests {}