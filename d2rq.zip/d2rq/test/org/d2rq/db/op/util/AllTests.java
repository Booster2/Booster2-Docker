package org.d2rq.db.op.util;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	OpUtilTest.class,
})

public class AllTests {}