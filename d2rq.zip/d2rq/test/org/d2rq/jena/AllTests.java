package org.d2rq.jena;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	JenaAPITest.class,
})

public class AllTests {}
