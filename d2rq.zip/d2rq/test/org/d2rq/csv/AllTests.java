package org.d2rq.csv;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	TranslationTableParserTest.class
})

public class AllTests {}