package org.d2rq.find;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	URIMakerRuleTest.class,
})

public class AllTests {}