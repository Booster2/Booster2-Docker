package org.d2rq.nodes;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	NodeMakerTest.class
})

public class AllTests {}